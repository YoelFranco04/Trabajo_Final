<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colegio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="icon" href="icons/interrogation.png">
    <link rel="stylesheet" href="css/style.css">
</head>

<body onload="mueveReloj()">
    <div class="container-lg-bg">

        <!-- Menú de navegación -->
        <?php include_once "menu.php"; ?>

        <!-- Banner -->
        <h1 class="bg-secondary text-trinity text-center p-2 " >Mantenimiento de Clases</h1>

        <!-- Formulario de Clases -->
        <form class="p-4 bg-info-subtle">

            <!-- Nombre de la Clase -->
            <div class="mb-3 row">
                <label for="nombre_clase" class="col-sm-3 col-form-label text-secondary-emphasis">Nombre de la Clase</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control text-primary-emphasis" id="nombre_clase"
                        name="nombre_clase" required placeholder="Ingrese el Nombre de la Clase">
                </div>
            </div>

            <!-- Dia -->
            <div class="mb-3 row">
                <label for="dia" class="col-sm-3 col-form-label text-secondary-emphasis">Día</label>
                <div class="col-sm-9">
                    <select id="dia" name="dia" class="form-select text-primary-emphasis" aria-label="Default select example">
                        <?php include_once "php/front/diasSelect.php"; ?>
                    </select>
                </div>
            </div>

            <!-- Turno -->
            <div class="mb-3 row">
                <label for="turno" class="col-sm-3 col-form-label text-secondary-emphasis">Turno</label>
                <div class="col-sm-9">
                    <select id="turno" name="turno" class="form-select text-primary-emphasis" aria-label="Default select example">
                        <?php include_once "php/front/turnosSelect.php"; ?>
                    </select>
                </div>
            </div>

            <!-- Id_entrenador-->
            <div class="mb-3 row">
                <label for="id_entrenador" class="col-sm-3 col-form-label text-secondary-emphasis">Entrenador</label>
                <div class="col-sm-9">
                    <select id="id_entrenador" name="id_entrenador" class="form-select text-primary-emphasis" aria-label="Default select example">
                        <?php include_once "php/front/entrenadoresSelect.php"; ?>
                    </select>
                </div>
            </div>

            <!-- Botones-->
            <div class="mb-3 row">
                <button type="submit" class="btn btn-success col-sm-3 m-2">Guardar</button>
                <button type="reset" class="btn btn-danger col-sm-3 m-2">Borrar</button>
            </div>

            <!-- Información -->
            <div class="mb-3 row">
                <label for="info" class="col-sm-3 col-form-label text-secondary-emphasis">Información</label>
                <div class="col-sm-9">
                    <div class="form-control text-primary-emphasis" id="info">
                        <?php include_once "php/front/clasesInsert.php"; ?>
                    </div>
                </div>
            </div>
        </form>
        <!-- Tabla de las Clases -->
        <table class="table table-dark table-striped table-hover container-lg text-center">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Nombre de la Clase</th>
                    <th scope="col">Día</th>
                    <th scope="col">Turno</th>
                    <th scope="col">Id_entrenador</th>
                </tr>
            </thead>
            <tbody>
                <?php include_once "php/front/clasesTable.php"; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/reloj.js"></script>
    <script src="js/main.js"></script>
</body>

</html>