<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colegio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="icons/interrogation.png">

</head>

<body onload="mueveReloj()">
    <div class="container-lg-bg">

        <!-- Menú de navegación -->
        <?php include_once "menu.php"; ?>

        <!-- Banner -->
        <h1 class="bg-secondary text-trinity text-center p-2">Sistema del Gimnasio</h1>

        <div id="carouselExampleCaptions" class="carousel carousel-dark slide">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="4" aria-label="Slide 5"></button>
            </div>

            <!-- Imagen Musculacion -->
            <div class="carousel-inner">
                <div class="carousel-item active">
                <img src="images/musculacionClase1.png" class="d-block w-100" alt="Imagen del Gimnasio">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Entrenamiento de Musculación</h5>
                        <p>Desarrolla tu fuerza y resistencia con rutinas de musculación personalizadas. ¡Vuelve más fuerte con cada sesión!</p>
                    </div>
                </div>

                <!-- Imagen Boxeo -->
                <div class="carousel-item">
                <img src="images/boxeoClase.png" class="d-block w-100" alt="Imagen de la clase de Boxeo">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Clases de Boxeo</h5>
                        <p>Aprende la técnica del boxeo, mejora tu agilidad y pon a prueba tu resistencia en nuestras clases dirigidas por expertos.</p>
                    </div>
                </div>

                <!-- Imagen Cancha de Futbol -->
                <div class="carousel-item">
                <img src="images/futbolClase.png" class="d-block w-100" alt="Imagen de la clase Futbol">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Fútbol</h5>
                        <p>Juega y mejora tus habilidades en el fútbol, ya sea en partidos amistosos o entrenamientos intensivos. ¡La cancha te espera!</p>
                    </div>
                </div>

                <!-- Imagen de Clase de Yoga -->
                <div class="carousel-item">
                <img src="images/yogaClase.png" class="d-block w-100" alt="Imagen de la clase de Yoga">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Clase de Yoga</h5>
                        <p>Relaja tu mente y cuerpo con nuestras clases de yoga. Perfectas para aumentar tu flexibilidad y reducir el estrés.</p>
                    </div>
                </div>

                <!-- Imagen de Clase de Natacion -->
                <div class="carousel-item">
                <img src="images/natacionClase.png" class="d-block w-100" alt="Imagen de la clase de Natacion">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Clase de Natación</h5>
                        <p>Sumérgete en nuestras clases de natación, ideales para mejorar tu resistencia y técnica en el agua mientras te mantienes en forma.</p>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
        <!-- Información adicional -->

        <h5 class="text-center p-4">Bienvenidos a la plataforma de administración del gimnasio. Aquí podrás gestionar los miembros, entrenadores, clases y más.</h5>
        
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/reloj.js"></script>
    <script src="js/main.js"></script>
</body>

</html>