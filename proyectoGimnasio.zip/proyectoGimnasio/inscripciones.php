<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colegio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="icons/interrogation.png">
</head>

<body onload="mueveReloj()">
    <div class="container-lg-bg">

        <!-- Menú de navegación -->
        <?php include_once "menu.php"; ?>

        <!-- Banner -->
        <h1 class="bg-secondary text-trinity text-center p-2">Mantenimiento de Inscripciones</h1>

        <!-- Formulario de Inscripciones -->
        <form class="p-4 bg-info-subtle">

            <!-- Fecha de Inscripcion -->
            <div class="mb-3 row">
                <label for="fecha_inscripcion" class="col-sm-3 col-form-label text-secondary-emphasis">Fecha de Inscripcion</label>
                <div class="col-sm-9">
                    <input type="date" class="form-control text-primary-emphasis" id="fecha_inscripcion"
                        name="fecha_inscripcion" required>
                </div>
            </div>

            <!-- Id_miembro-->
            <div class="mb-3 row">
                <label for="id_miembro" class="col-sm-3 col-form-label text-secondary-emphasis">Miembro</label>
                <div class="col-sm-9">
                    <select id="id_miembro" name="id_miembro" class="form-select text-primary-emphasis" aria-label="Default select example">
                        <?php include_once "php/front/miembrosSelect.php"; ?>
                    </select>
                </div>
            </div>

            <!-- Id_clase-->
            <div class="mb-3 row">
                <label for="id_clase" class="col-sm-3 col-form-label text-secondary-emphasis">Clase</label>
                <div class="col-sm-9">
                    <select id="id_clase" name="id_clase" class="form-select text-primary-emphasis" aria-label="Default select example">
                        <?php include_once "php/front/clasesSelect.php"; ?>
                    </select>
                </div>
            </div>

            <!-- Botones-->
            <div class="mb-3 row">
                <button type="submit" class="btn btn-success col-sm-3 m-2">Guardar</button>
                <button type="reset" class="btn btn-danger col-sm-3 m-2">Borrar</button>
            </div>

            <!-- Información -->
            <div class="mb-3 row">
                <label for="info" class="col-sm-3 col-form-label text-secondary-emphasis">Información</label>
                <div class="col-sm-9">
                    <div class="form-control text-primary-emphasis" id="info">
                        <?php include_once "php/front/inscripcionesInsert.php"; ?>
                    </div>
                </div>
            </div>
        </form>
        <!-- Tabla de Inscripciones -->
        <table class="table table-dark table-striped table-hover container-lg text-center">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">fecha_inscripcion</th>
                    <th scope="col">Id_miembro</th>
                    <th scope="col">Id_clase</th>
                </tr>
            </thead>
            <tbody>
                <?php include_once "php/front/inscripcionesTable.php"; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/reloj.js"></script>
    <script src="js/main.js"></script>
</body>

</html>