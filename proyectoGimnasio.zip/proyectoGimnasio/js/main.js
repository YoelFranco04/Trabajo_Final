function confirmarBorrar() {
    return confirm("Desea borrar borrar la Clase?")
}