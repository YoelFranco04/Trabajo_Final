<!-- Menú de navegación -->
<nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <a class="navbar-brand text-succes" href="index.php">Home</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active text-primary" aria-current="page" href="miembros.php">Miembros</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active text-primary" aria-current="page" href="entrenadores.php">Entrenadores</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active text-primary" aria-current="page" href="clases.php">Clases</a>
                </li>
                </li>
                <li class="nav-item">
                    <a class="nav-link active text-primary" aria-current="page" href="inscripciones.php">Inscripciones</a>
                </li>
                </li>
                <li class="nav-item">
                    <a class="nav-link active text-primary" aria-current="page" href="configuracion.php">Configuración</a>
                </li>
                <li class="nav-item ">
                    <input type="text" id="reloj" class="text-success text-center bg-primary-subtle" readonly value="reloj">
                </li>
            </ul>
            <form class="d-flex" role="search" class="text-center">
                <input class="form-control me-2" name="buscar" value="" type="search" placeholder="Buscar" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Buscar</button>
            </form>
        </div>
    </div>
</nav>
<!-- Fin Menú de navegación -->