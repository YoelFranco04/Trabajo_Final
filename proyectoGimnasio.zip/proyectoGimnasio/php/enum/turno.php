<?php
enum Turno{
    case MAÑANA;
    case TARDE;
    case NOCHE;
}
?>