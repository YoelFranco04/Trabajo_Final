<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['nombre_clase']) && $_REQUEST['nombre_clase'] != '' 
) {
    $nombre_clase = $_REQUEST['nombre_clase'];
    $dia = $_REQUEST['dia'];
    $turno = $_REQUEST['turno'];
    $id_entrenador = $_REQUEST['id_entrenador'];

    //echo $titulo.' '.$profesor.' '.$dia.' '.$turno;
    $tabla = "clases";
    $campos = "nombre_clase,dia,turno,id_entrenador";
    $values = "'" . $nombre_clase . "','" . $dia . "','" . $turno . "','" . $id_entrenador . "'";
    $connector=new Connector();
    $connector->insert($tabla,$campos,$values);
    echo 'Se ingreso un nuevo Clase!';
} else {
    echo 'Ingrese un nueva Clase!';
}
?>