<?php
include_once "php/connectors/connector.php";
$connector=new Connector();
$registros=$connector->getAll("clases");
foreach ($registros as $registro) {
    echo "<option value='" . $registro['id'] . "'>" .
            $registro['id'].', '.$registro['nombre_clase'].', '.$registro['dia']
            .', '.$registro['turno'].', '.$registro['id_entrenador']
        ."</option><br>";
}
?>