<?php
include_once "php/connectors/connector.php";
$connector = new Connector();
//$registros = $connector->getAll("cursos");
$buscar = "";
if (isset($_REQUEST['buscar'])) $buscar = $_REQUEST['buscar'];
$registros = $connector->get("clases", "nombre_clase like '%" . $buscar . "%'");
foreach ($registros as $registro) {
    echo ("<tr>");
    echo ("<td>" . $registro['id'] . "</td>");
    echo ("<td>" . $registro['nombre_clase'] . "</td>");
    echo ("<td>" . $registro['dia'] . "</td>");
    echo ("<td>" . $registro['turno'] . "</td>");
    echo ("<td>" . $registro['id_entrenador'] . "</td>");
    echo ("</tr>");

}
?>