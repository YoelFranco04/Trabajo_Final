<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['fecha_inscripcion']) && $_REQUEST['fecha_inscripcion'] != ''
) {
    $fecha_inscripcion = $_REQUEST['fecha_inscripcion'];
    $id_miembro = $_REQUEST['id_miembro'];
    $id_clase = $_REQUEST['id_clase'];

    //echo $nombre.' '.$apellido.' '.$edad.' '.$id_curso;
    
    $tabla = "inscripciones";
    $campos = "fecha_inscripcion,id_miembro,id_clase";
    $values = "'" . $fecha_inscripcion . "','" . $id_miembro . "','" . $id_clase . "'";
    $connector=new Connector();
    $connector->insert($tabla,$campos,$values);
    echo 'Se ingreso una Inscripcion!';
} else {
    echo 'Ingrese una nueva Inscripcion!';
}
?>