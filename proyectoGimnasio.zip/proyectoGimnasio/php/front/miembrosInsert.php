<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['nombre']) && $_REQUEST['nombre'] != '' &&
    isset($_REQUEST['apellido']) && $_REQUEST['apellido'] != ''
) {
    $nombre = $_REQUEST['nombre'];
    $apellido = $_REQUEST['apellido'];
    $fecha_inscripcion = $_REQUEST['fecha_inscripcion'];

    //echo $nombre.' '.$apellido.' '.$edad.' '.$id_curso;
    $tabla = "miembros";
    $campos = "nombre,apellido,fecha_inscripcion";
    $values = "'" . $nombre . "','" . $apellido . "','" . $fecha_inscripcion ."'";
    $connector=new Connector();
    $connector->insert($tabla,$campos,$values);
    echo 'Se ingreso un nuevo Miembro!';
} else {
    echo 'Ingrese un nuevo Miembro!';
}
?>
<!-- drop database if exists gimnasio;
create database gimnasio;
use gimnasio;

drop table if exists miembros;
drop table if exists entrenadores;
drop table if exists cursos;
drop table if exists inscripciones;

create table miembros(
		id integer AUTO_INCREMENT,
		nombre varchar(25) not null,
		apellido varchar(25) not null,
		fecha_inscripcion date,
		activo boolean default TRUE,
		primary key(id)
);


create table entrenadores(
		id integer AUTO_INCREMENT,
		nombre varchar(25) not null,
		apellido varchar(25) not null,
		especialidad varchar(25) not null,
		activo boolean default TRUE,
		primary key(id)
);


create table clases(
		id integer AUTO_INCREMENT,
		nombre_clase varchar(25) not null,
		dia varchar(12) not null 
                check(dia IN('LUNES','0MARTES','MIERCOLES','JUEVES','VIERNES','SABADO')),
		turno varchar(25) not null
                check(turno IN('MAÑANA','TARDE','NOCHE')),
		id_entrenador int null references entrenadores(id),
		activo boolean default TRUE,
		primary key(id)
);


create table inscripciones(
		id integer AUTO_INCREMENT,
		id_miembro int null references miembros(id),
		id_clase int null references clases(id),
        fecha_inscripcion date,
		activo boolean default TRUE,
		primary key(id)
        );c:\xampp\htdocs\OBJETOS\clase37\sql -->