<?php ini_set("display_errors","1");?>
<?php

//http://localhost/objetos/proyectoGimnasio/php/test/test_PDO.php
    
// sqlite
$myPDO = new PDO('sqlite:../../data/colegio.db');
$result = $myPDO->query("select sqlite_version()");
echo $result->rowCount().'<br>';        //0
foreach($result as $row){
    print $row[0] . "\n";
}
?>