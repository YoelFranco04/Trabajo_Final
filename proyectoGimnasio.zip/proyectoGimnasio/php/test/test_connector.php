<?php ini_set("display_errors","1");?>
<?php
include_once '../connectors/connector.php';

//http://localhost/objetos/proyectoGimnasio/php/test/test_connector.php
    

echo '<h3>-- Inicio de Test Connector --</h3>';
$connector=new Connector();
$sql="select sqlite_version()";        //sqlite
try{
    $registros = $connector->getConnection()->query($sql);
    echo 'Conexión exitosa!<br>';
    foreach($registros as $row){
        echo 'Se conecto a '.$row[0].'<br>';
    }
}catch(Exception $e){
    echo 'Error de conexión2!<br>';
    echo $e.'<br>';
}
echo '<h3>-- Fin de Test Connector --</h3>';

echo '<h4>-- Inicio del Test de los otros METODOS --</h4>';

$connector->insert(
                    "miembros",
                    "nombre,apellido,fecha_inscripcion",
                    "'Laura','Gonzalez','2023-08-05'"
                );



$connector->delete("miembros","id=6");
$connector->update("miembros","apellido='Rivas'","id=2");

echo '<h4>-- Fin del Test de los otros METODOS --</h4>';



echo '<h4>-- Inicio del Test del METEDO .get() --</h4>';

$registros = $connector->getAll("miembros");
echo "Miembros:<br>";
foreach($registros as $row){
    echo $row['id'].", ".$row['nombre'].", ".$row['apellido'].", ".
         $row['fecha_inscripcion']."<br>";
}
echo "<br><br>";

$registros = $connector->getAll("entrenadores");
echo "Entrenadores:<br>";
foreach($registros as $row){
    echo $row['id'].", ".$row['nombre'].", ".$row['apellido'].", ".
         $row['especialidad']."<br>";
}
echo "<br><br>";

$registros = $connector->getAll("clases");
echo "Clases:<br>";
foreach($registros as $row){
    echo $row['id'].", ".$row['nombre_clase'].", ".$row['dia'].", ".$row['turno'].", ".
         $row['id_entrenador']."<br>";
}
echo "<br><br>";

$registros = $connector->getAll("inscripciones");
echo "Inscripciones:<br>";
foreach($registros as $row){
    echo $row['id'].", ".$row['fecha_inscripcion'].", ".$row['id_miembro'].", ".
         $row['id_clase']."<br>";
}
echo "<br><br>";

echo '<h4>-- Fin del Test del METODO .get() --</h4>';

echo '<h4>-- Fin del Test de los otros METODOS --</h4>';

?>