-- Active: 1732113316951@@127.0.0.1@3306

-- CTROL - ENTER para ejecutar una sentencia
-- CTROL - SHIFT - ENTER para ejecutar todo el script


drop table if exists miembros;
drop table if exists entrenadores;
drop table if exists clases;
drop table if exists inscripciones;

create table miembros(
    	id integer,
		nombre varchar(25) not null,
		apellido varchar(25) not null,
		fecha_inscripcion date,
		activo boolean default TRUE,
		primary key(id)
);


create table entrenadores(
    	id integer,
		nombre varchar(25) not null,
		apellido varchar(25) not null,
		especialidad varchar(25) not null,
		activo boolean default TRUE,
		primary key(id)
);


create table clases(
    	id integer,
		nombre_clase varchar(25) not null,
		dia varchar(12) not null 
                check(dia IN('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO')),
		turno varchar(25) not null
                check(turno IN('MAÑANA','TARDE','NOCHE')),
		id_entrenador integer null references entrenadores(id),
		activo boolean default TRUE,
		primary key(id)
);


create table inscripciones(
    	id integer,
		fecha_inscripcion date,
		id_miembro integer null references miembros(id),
		id_clase integer null references clases(id),
		activo boolean default TRUE,
		primary key(id)
        );