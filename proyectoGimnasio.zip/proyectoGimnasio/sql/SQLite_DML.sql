-- Active: 1732113316951@@127.0.0.1@3306
-- Insertar datos en la tabla miembros
INSERT INTO miembros (id, nombre, apellido, fecha_inscripcion, activo) VALUES
(1, 'Juan', 'Pérez', '2023-05-15', TRUE),
(2, 'Ana', 'González', '2023-06-10', TRUE),
(3, 'Carlos', 'Martínez', '2023-07-01', TRUE),
(4, 'Lucía', 'Rodríguez', '2023-08-05', TRUE),
(5, 'Pedro', 'García', '2023-09-12', TRUE),
(6, 'Marta', 'Fernández', '2023-10-14', TRUE),
(7, 'Luis', 'Hernández', '2023-11-01', TRUE),
(8, 'Sara', 'López', '2023-04-20', TRUE),
(9, 'David', 'Sánchez', '2023-06-30', TRUE),
(10, 'Isabel', 'Martín', '2023-09-25', TRUE);

-- Insertar datos en la tabla entrenadores
INSERT INTO entrenadores (id, nombre, apellido, especialidad, activo) VALUES
(1, 'José', 'Mora', 'Yoga', TRUE),
(2, 'Laura', 'Díaz', 'Pilates', TRUE),
(3, 'Carlos', 'Reyes', 'Spinning', TRUE),
(4, 'Elena', 'Pérez', 'Crossfit', TRUE),
(5, 'Miguel', 'Gutiérrez', 'Natación', TRUE),
(6, 'Sandra', 'Vega', 'Boxeo', TRUE),
(7, 'Pedro', 'Martín', 'Fútbol', TRUE),
(8, 'Raúl', 'Gómez', 'Musculación', TRUE),
(9, 'Sofía', 'Torres', 'Zumba', TRUE),
(10, 'Ricardo', 'Ramírez', 'Aeróbicos', TRUE);

-- Insertar datos en la tabla clases
INSERT INTO clases (id, nombre_clase, dia, turno, id_entrenador, activo) VALUES
(1, 'Yoga Avanzado', 'LUNES', 'MAÑANA', 1, TRUE),
(2, 'Pilates Básico', 'MARTES', 'TARDE', 2, TRUE),
(3, 'Spinning Intensivo', 'MIERCOLES', 'NOCHE', 3, TRUE),
(4, 'Crossfit para Todos', 'JUEVES', 'MAÑANA', 4, TRUE),
(5, 'Natación Infantil', 'VIERNES', 'TARDE', 5, TRUE),
(6, 'Boxeo para principiantes', 'SABADO', 'MAÑANA', 6, TRUE),
(7, 'Fútbol Recreativo', 'LUNES', 'TARDE', 7, TRUE),
(8, 'Musculación Personalizada', 'MARTES', 'MAÑANA', 8, TRUE),
(9, 'Zumba Fitness', 'MIERCOLES', 'TARDE', 9, TRUE),
(10, 'Aeróbicos de Bajo Impacto', 'JUEVES', 'NOCHE', 10, TRUE);

-- Insertar datos en la tabla inscripciones
INSERT INTO inscripciones (id, fecha_inscripcion, id_miembro, id_clase, activo) VALUES
(1, '2023-05-15', 1, 1, TRUE),
(2, '2023-06-10', 2, 2, TRUE),
(3, '2023-07-01', 3, 3, TRUE),
(4, '2023-08-05', 4, 4, TRUE),
(5, '2023-09-12', 5, 5, TRUE),
(6, '2023-10-14', 6, 6, TRUE),
(7, '2023-11-01', 7, 7, TRUE),
(8, '2023-04-20', 8, 8, TRUE),
(9, '2023-06-30', 9, 9, TRUE),
(10, '2023-09-25', 10, 10, TRUE);
