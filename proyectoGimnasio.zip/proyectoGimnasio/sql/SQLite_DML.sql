-- Active: 1732545683759@@127.0.0.1@3306
-- Insertar registros en la tabla miembros
insert into miembros(id, nombre, apellido, fecha_inscripcion, activo) values
(1, 'Juan', 'Pérez', '2023-01-01', TRUE),
(2, 'Ana', 'Gómez', '2023-02-15', TRUE),
(3, 'Carlos', 'López', '2023-03-10', TRUE),
(4, 'Luisa', 'Martínez', '2023-04-20', TRUE),
(5, 'Pedro', 'Rodríguez', '2023-05-05', TRUE),
(6, 'Marta', 'Fernández', '2023-06-25', TRUE),
(7, 'Luis', 'García', '2023-07-15', TRUE),
(8, 'Sofía', 'Hernández', '2023-08-01', TRUE),
(9, 'David', 'Torres', '2023-09-10', TRUE),
(10, 'Clara', 'Ramírez', '2023-10-05', TRUE),
(11, 'Fernando', 'Sánchez', '2023-11-15', TRUE),
(12, 'Carmen', 'Jiménez', '2023-12-01', TRUE),
(13, 'Jorge', 'Díaz', '2023-01-22', TRUE),
(14, 'Raquel', 'Moreno', '2023-02-10', TRUE),
(15, 'Tomás', 'Alvarez', '2023-03-05', TRUE);

-- Insertar registros en la tabla entrenadores (con especialidades solicitadas)
insert into entrenadores(id, nombre, apellido, especialidad, activo) values
(1, 'Ricardo', 'González', 'Boxeo', TRUE),
(2, 'Laura', 'Vázquez', 'Yoga', TRUE),
(3, 'Pedro', 'Martín', 'Musculación', TRUE),
(4, 'Elena', 'Serrano', 'Natación', TRUE),
(5, 'Carlos', 'Pérez', 'Fútbol', TRUE);

-- Insertar registros en la tabla clases
insert into clases(id, nombre_clase, dia, turno, id_entrenador, activo) values
(1, 'Boxeo Básico', 'LUNES', 'MAÑANA', 1, TRUE),
(2, 'Yoga para Principiantes', 'MARTES', 'TARDE', 2, TRUE),
(3, 'Musculación Avanzada', 'MIERCOLES', 'NOCHE', 3, TRUE),
(4, 'Natación Inicial', 'JUEVES', 'MAÑANA', 4, TRUE),
(5, 'Fútbol Infantil', 'VIERNES', 'TARDE', 5, TRUE),
(6, 'Boxeo Profesional', 'LUNES', 'TARDE', 1, TRUE),
(7, 'Yoga Relax', 'MARTES', 'MAÑANA', 2, TRUE),
(8, 'Musculación para Todos', 'MIERCOLES', 'TARDE', 3, TRUE),
(9, 'Natación para Niños', 'JUEVES', 'TARDE', 4, TRUE),
(10, 'Fútbol Adultos', 'VIERNES', 'MAÑANA', 5, TRUE),
(11, 'Boxeo para Todos', 'LUNES', 'NOCHE', 1, TRUE),
(12, 'Yoga Avanzado', 'MARTES', 'NOCHE', 2, TRUE),
(13, 'Musculación Funcional', 'MIERCOLES', 'MAÑANA', 3, TRUE),
(14, 'Natación Profesional', 'JUEVES', 'MAÑANA', 4, TRUE),
(15, 'Fútbol Profesional', 'VIERNES', 'NOCHE', 5, TRUE);

-- Insertar registros en la tabla inscripciones
insert into inscripciones(id, fecha_inscripcion, id_miembro, id_clase, activo) values
(1, '2023-01-05', 1, 1, TRUE),
(2, '2023-02-17', 2, 2, TRUE),
(3, '2023-03-12', 3, 3, TRUE),
(4, '2023-04-25', 4, 4, TRUE),
(5, '2023-05-10', 5, 5, TRUE),
(6, '2023-06-30', 6, 6, TRUE),
(7, '2023-07-20', 7, 7, TRUE),
(8, '2023-08-05', 8, 8, TRUE),
(9, '2023-09-15', 9, 9, TRUE),
(10, '2023-10-10', 10, 10, TRUE),
(11, '2023-11-18', 11, 11, TRUE),
(12, '2023-12-10', 12, 12, TRUE),
(13, '2023-01-25', 13, 13, TRUE),
(14, '2023-02-20', 14, 14, TRUE),
(15, '2023-03-10', 15, 15, TRUE);
