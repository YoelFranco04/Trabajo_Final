-- Active: 1732113316951@@127.0.0.1@3306
-- 0. Versión de SQLite
select sqlite_version();

select 'hola';

-- 1. Seleccionar todos los miembros
SELECT * FROM miembros;

-- 2. Seleccionar todos los entrenadores
SELECT * FROM entrenadores;

-- 3. Seleccionar las clases activas
SELECT * FROM clases WHERE activo = TRUE;

-- 4. Seleccionar miembros activos
SELECT * FROM miembros WHERE activo = TRUE;

-- 5. Contar la cantidad de miembros por clase
SELECT id_clase, COUNT(*) AS cantidad_miembros
FROM inscripciones
GROUP BY id_clase;

-- 6. Obtener información de un miembro específico
SELECT * FROM miembros WHERE id = 1;

-- 7. Obtener entrenadores especializados en una área específica
SELECT * FROM entrenadores WHERE especialidad = 'Fuerza';

-- 8. Obtener clases que se imparten los viernes
SELECT * FROM clases WHERE dia = 'VIERNES';

-- 9. Obtener nombres y apellidos de miembros junto con el nombre de la clase
SELECT m.nombre, m.apellido, c.nombre_clase
FROM miembros m
LEFT JOIN inscripciones i ON m.id = i.id_miembro
LEFT JOIN clases c ON i.id_clase = c.id;

-- 10. Obtener la lista de entrenadores y la cantidad de clases que imparten
SELECT e.nombre, e.apellido, COUNT(*) AS cantidad_clases
FROM entrenadores e
LEFT JOIN clases c ON e.id = c.id_entrenador
GROUP BY e.id;

-- 11. Obtener la cantidad de inscripciones activas por clase
SELECT id_clase, COUNT(*) AS inscripciones_activas
FROM inscripciones
WHERE activo = TRUE
GROUP BY id_clase;